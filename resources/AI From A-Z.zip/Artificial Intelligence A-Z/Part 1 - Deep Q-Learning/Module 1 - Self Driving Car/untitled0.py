# -*- coding: utf-8 -*-
"""
Created on Mon Nov 12 18:43:02 2018

@author: Adrián Valero
"""
import time

print("TEST")
time.sleep(1000)